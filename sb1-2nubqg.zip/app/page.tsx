"use client";

import { useEffect, useState } from 'react';
import { DomainCard } from '@/components/DomainCard';
import { portfolio } from '@/config/portfolio';
import { DomainListing } from '@/lib/types';

function getDomainFromWindow(): string | null {
  if (typeof window === 'undefined') return null;
  
  // Remove 'www.' if present and get the domain
  const hostname = window.location.hostname.replace(/^www\./, '');
  
  // If we're on berwal.com, show portfolio
  if (hostname === 'berwal.com') return null;
  
  // Check if this domain exists in our portfolio
  const domainExists = portfolio.domains.some(d => 
    d.name.toLowerCase() === hostname.toLowerCase()
  );
  return domainExists ? hostname : null;
}

export default function Home() {
  const [currentDomain, setCurrentDomain] = useState<DomainListing | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const domain = getDomainFromWindow();
    if (domain) {
      const domainData = portfolio.domains.find(
        d => d.name.toLowerCase() === domain.toLowerCase()
      );
      setCurrentDomain(domainData || null);
    }
    setIsLoading(false);
  }, []);

  if (isLoading) {
    return (
      <main className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 p-4 md:p-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="animate-pulse">Loading...</div>
        </div>
      </main>
    );
  }

  // If we have a specific domain, show its landing page
  if (currentDomain) {
    return (
      <main className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 p-4 md:p-8">
        <div className="max-w-2xl mx-auto">
          <DomainCard
            domain={currentDomain}
            contactEmail={portfolio.contactEmail}
            features={portfolio.defaultFeatures}
          />
        </div>
      </main>
    );
  }

  // Otherwise, show the portfolio page
  return (
    <main className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Premium Domain Portfolio</h1>
          <p className="text-xl text-gray-600">Browse our collection of premium domain names</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {portfolio.domains.map((domain) => (
            <a
              key={domain.name}
              href={`http://${domain.name}`}
              className="transform transition-transform hover:-translate-y-1"
            >
              <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-xl transition-shadow">
                <h2 className="text-2xl font-semibold mb-2">{domain.name}</h2>
                {domain.description && (
                  <p className="text-gray-600 mb-4">{domain.description}</p>
                )}
                {domain.suggestedPrice && (
                  <p className="text-lg font-medium text-indigo-600">
                    Starting at ${domain.suggestedPrice.toLocaleString()}
                  </p>
                )}
                {domain.category && (
                  <span className="inline-block mt-2 px-3 py-1 bg-indigo-100 text-indigo-800 rounded-full text-sm">
                    {domain.category}
                  </span>
                )}
              </div>
            </a>
          ))}
        </div>
      </div>
    </main>
  );
}